﻿using CRUDWithCoreWEBAPI_EFCore.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CRUDWithCoreWEBAPI_EFCore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ActorsController : ControllerBase
    {
        private readonly APPDBContext _dbcontext;

        public ActorsController(APPDBContext dbcontext)
        {
            _dbcontext= dbcontext;
        }
        //public static List<Actor> lstActor = new List<Actor>()
        //{
        //    new Actor{ ID=1,Name="RRR",FirstName="Ram",LastName="Charan",Country="Indian"},
        //     new Actor{ ID=2,Name="RRR",FirstName="NT",LastName="R",Country="Indian"},
        //      new Actor{ ID=3,Name="RRR",FirstName="SS",LastName="RAJ",Country="Indian"},
        //       new Actor{ ID=4,Name="RRR",FirstName="MM",LastName="Krem",Country="Indian"},
        //        new Actor{ ID=5,Name="RRR",FirstName="Alia",LastName="Butt",Country="Indian"}

        //};


        //[HttpGet]
        //public async Task<ActionResult<List<Actor>>> getActors()
        //{
        //    return Ok(lstActor);
        //}

        //[HttpPost]
        //public async Task<ActionResult<List<Actor>>> AddActor(Actor actor)
        //{
        //    lstActor.Add(actor);
        //    return Ok(lstActor);
        //}

        //[HttpGet("{Id}")]
        //public async Task<ActionResult<Actor>> GetActor(int Id)
        //{
        //    var actor = lstActor.Find(x => x.ID == Id);
        //    if (actor == null)
        //        return BadRequest("Actor Not Found");
        //    return Ok(actor);
        //}

        //[HttpPut]
        //public async Task<ActionResult<List<Actor>>> UpdateActors(Actor actor)
        //{
        //    var act = lstActor.Find(x => x.ID == actor.ID);

        //    if (actor == null)
        //    {
        //        return BadRequest("Actor Not Found");

        //    }

        //    act.Name = actor.Name;
        //    act.LastName = actor.LastName;
        //    act.FirstName = actor.FirstName;
        //    act.Country = actor.Country;

        //    return Ok(act);

        //}

        //[HttpDelete("{Id}")]
        //public async Task<ActionResult<List<Actor>>> DeleteActor(int Id)
        //{
        //    var actor = lstActor.Find(x =>x.ID == Id);
        //    if (actor == null)
        //    {
        //        return BadRequest("Actor Not Found"); 
        //    }

        //    lstActor.Remove(actor);

        //    return Ok(lstActor);

        //}

        [HttpGet]
        public async Task<ActionResult<List<Actor>>> getActors()
        {
            return Ok(await _dbcontext.Actors.ToListAsync());
        }

        [HttpPost]
        public async Task<ActionResult<List<Actor>>> AddActor(Actor actor)
        {
            _dbcontext.Actors.Add(actor);
            await _dbcontext.SaveChangesAsync();

            return Ok(await _dbcontext.Actors.ToListAsync());
        }

        [HttpGet("{Id}")]
        public async Task<ActionResult<Actor>> GetActor(int Id)
        {
            return Ok(await _dbcontext.Actors.FindAsync());
        }
        [HttpPut]
        public async Task<ActionResult<List<Actor>>> UpdateActors(Actor actor)
        {
            var act = await _dbcontext.Actors.FindAsync(actor.ID);

            if (actor == null)
            {
                return BadRequest("Actor Not Found");

            }

            act.Name = actor.Name;
            act.LastName = actor.LastName;
            act.FirstName = actor.FirstName;
            act.Country = actor.Country;

            await _dbcontext.SaveChangesAsync();

            return Ok(await _dbcontext.Actors.ToListAsync());

        }

        [HttpDelete("{Id}")]
        public async Task<ActionResult<List<Actor>>> DeleteActor(int Id)
        {
            var actor = await _dbcontext.Actors.FindAsync(Id); 
            if (actor == null)
            {
                return BadRequest("Actor Not Found");
            }

              _dbcontext.Actors.Remove(actor);
            await _dbcontext.SaveChangesAsync();

            return Ok(await _dbcontext.Actors.ToListAsync());

        }
    }
}
