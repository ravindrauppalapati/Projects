﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace CRUDWithCoreWEBAPI_EFCore.Model
{
    public class APPDBContext : DbContext
    {
        public APPDBContext(DbContextOptions <APPDBContext> options) : base(options) { }
        
        public DbSet<Actor> Actors { get; set; }
    }
}
