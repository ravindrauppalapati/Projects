﻿using Microsoft.AspNetCore.Mvc;
using SampleEComm.Models;
using SampleEComm.Repository;

namespace SampleEComm.Controllers
{
    public class UserController : Controller
    { private readonly AppDbContext _Context;
        private readonly IBookRepository _bookRepository;
        private readonly IClothRepository _clothRepository;
        public UserController(AppDbContext context,IBookRepository bookRepository,IClothRepository clothRepository)
        {
            _bookRepository = bookRepository; 
            _clothRepository = clothRepository; 
            _Context = context;
        }
        public IActionResult Index()
        {
            return View();
        }
        public async Task<IActionResult> BookIndex()
        {
            return View(await _bookRepository.GetBooksAll());
        }
        public async Task<IActionResult> ClothIndex()
        {
            return View(await _clothRepository.GetClothsAll());
        }
    }
}
