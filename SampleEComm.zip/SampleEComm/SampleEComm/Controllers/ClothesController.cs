﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SampleEComm.Models;
using SampleEComm.Repository;

namespace SampleEComm.Controllers
{
    public class ClothesController : Controller
    {
        private readonly AppDbContext _context;
        private readonly IClothRepository _clothRepository;

        public ClothesController(AppDbContext context,IClothRepository clothRepository)
        {
            _context = context;
            _clothRepository = clothRepository;
        }

        // GET: Clothes
        public async Task<IActionResult> Index()
        {
            return View(await _clothRepository.GetClothsAll());
        }

        // GET: Clothes/Details/5
        public async Task<IActionResult> Details(int id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cloth = await _clothRepository.GetClothbyId(id);
            if (cloth == null)
            {
                return NotFound();
            }

            return View(cloth);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create( Cloth cloth,IFormFile file)
        {
            cloth.ImagePath = file.FileName;
            if (ModelState.IsValid)
            {
                if (file != null && file.Length > 0)
                {
                    var filepath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads", file.FileName);
                    using (var stream = System.IO.File.Create(filepath))
                    {
                        file.CopyTo(stream);
                    }
                }
                await _clothRepository.InsertCloth(cloth);
                await _clothRepository.SaveChanges();
            }
            return RedirectToAction("Index");
        }

       [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cloth = await _clothRepository.GetClothbyId(id);
            if (cloth == null)
            {
                return NotFound();
            }
            return View(cloth);
        }

         
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(  Cloth cloth,IFormFile file)
        {
            cloth.ImagePath = file.FileName;
            if (ModelState.IsValid)
            {
                if (file != null && file.Length > 0)
                {
                    var filepath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads", file.FileName);
                    using (var stream = System.IO.File.Create(filepath))
                    {
                        file.CopyTo(stream);
                    }
                }
                await _clothRepository.UpdateCloth(cloth);
                await _clothRepository.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        // GET: Clothes/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cloth = await _clothRepository.GetClothbyId(id);
            if (cloth == null)
            {
                return NotFound();
            }

            return View(cloth);
        }

     
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var cloth = await _clothRepository.GetClothbyId(id);
            if (cloth != null)
            {
                _context.cloths.Remove(cloth);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        [HttpPost]
        public ActionResult Logout( )
        {
           HttpContext.Session.Clear();
            return RedirectToAction("Index", "Login");
        }
    }
}
