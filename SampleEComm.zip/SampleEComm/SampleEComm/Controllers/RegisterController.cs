﻿using Microsoft.AspNetCore.Mvc;
using SampleEComm.Models;
using SampleEComm.Repository;

namespace SampleEComm.Controllers
{
    public class RegisterController : Controller
    {
        private readonly IUserRepository _userRepository;

        private readonly AppDbContext _Context;
        public RegisterController(IUserRepository user, AppDbContext context)
        {
            _Context = context;
            _userRepository = user;
        }
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Index(User user)
        {
            await _userRepository.RegistrationValidate(user);
            return RedirectToAction("Index","Login");

        }
    }
}
