﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SampleEComm.Models;
using SampleEComm.Repository;

namespace SampleEComm.Controllers
{
    public class BooksController : Controller
    {
        private readonly AppDbContext _context;
        private readonly IBookRepository _bookRepository;
        private readonly IUserRepository _userRepository;

        public BooksController(AppDbContext context, IBookRepository bookRepository, IUserRepository userRepository)
        {
            _context = context;
            _bookRepository = bookRepository;
            _userRepository = userRepository;
        }

        // GET: Books
        public async Task<IActionResult> Index()
        {
            return View(await _bookRepository.GetBooksAll());
        }

        // GET: Books/Details/5
        public async Task<IActionResult> Details(int Id)
        {
            if (Id == null)
            {
                return NotFound();
            } 
             Book book = await _bookRepository.GetBookbyId(Id);
            if (book == null)
            {
                return NotFound();
            }

            return View(book);
        }

        // GET: Books/Create
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        } 
      
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Book book,IFormFile file )
        {
            book.ImagePath = file.FileName;

            //if (ModelState.IsValid)
            //{
                if (file != null && file.Length > 0)
                {
                    var filepath = Path.Combine(Directory.GetCurrentDirectory(),"wwwroot/uploads",file.FileName);
                    using (var stream = System.IO.File.Create(filepath))
                    {
                        file.CopyTo(stream);    
                    }
                }
               await _bookRepository.InsertBook(book);
                await _bookRepository.SaveChanges();
            //}
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var book = await _bookRepository.GetBookbyId(id);
            if (book == null)
            {
                return NotFound();
            }
            return View(book);
        }

       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit( Book book,IFormFile file)
        {  
            book.ImagePath = file.FileName;
            //if (ModelState.IsValid)
            //{
                if (file != null && file.Length > 0)
                {
                    var filepath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads", file.FileName);
                    using (var stream = System.IO.File.Create(filepath))
                    {
                        file.CopyTo(stream);
                    }
                }
                await _bookRepository.UpdateBook(book);
                await _bookRepository.SaveChanges();
            //}
            return RedirectToAction("Index");
        }

        // GET: Books/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var book = await _bookRepository.GetBookbyId(id);
            if (book == null)
            {
                return NotFound();
            }

            return View(book);
        }

        // POST: Books/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var book = await _bookRepository.GetBookbyId(id); 
            if (book != null)
            {
                _context.books.Remove(book); 
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public ActionResult TopUser()
        {
            return View( _userRepository.TopUsers());
        }

        [HttpPost]
        public ActionResult ViewUserTransaction()
        {
            return View(_userRepository.ReturnTransaction());
        }
        [HttpPost]
        public ActionResult Logout()
        {
            HttpContext.Session.Clear(); 
            return RedirectToAction("Index", "Login");
        }

    }
}
