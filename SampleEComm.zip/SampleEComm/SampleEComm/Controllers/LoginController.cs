﻿using Microsoft.AspNetCore.Mvc;
using SampleEComm.Models;
using SampleEComm.Repository;

namespace SampleEComm.Controllers
{
    public class LoginController : Controller
    {
        private readonly AppDbContext _context;
        private readonly IUserRepository _userRepository;
        const string SessionUserId = "_UserId";
        const string SessionUserName = "_UserName";
        const string SessionUserType = "_UserType";
        public LoginController(IUserRepository userRepository, AppDbContext context)
        {
            _context = context;
            _userRepository = userRepository;
        }
        [HttpGet]

        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Index(string userName, string Password)
        {
            if (userName == "admin" || Password == "admin")
            {
                return RedirectToAction("Index", "Books");
            }
            else if (userName != null && Password != null)
            {

                User user = await _userRepository.LoginValidate(userName, Password);
                if (user != null)
                {
                    HttpContext.Session.SetString(SessionUserId, user.UserId.ToString());
                    HttpContext.Session.SetString(SessionUserName, user.UserName.ToString());
                    HttpContext.Session.SetString(SessionUserType, "user");
                    return RedirectToAction("BookIndex", "User");
                 }
                 else if (userName == "admin" && Password == "admin") //admin login
                  {
                        
                    HttpContext.Session.SetString(SessionUserType, "admin");
                    return RedirectToAction("Index", "Books");
                  }
                    else
                  {
                        ViewBag.loginError = "Invalid username or password";
                        return View();
                  } 
            }
            return View();
        }
    }
}
