﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SampleEComm.Models
{
    public class Book
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public double Price { get; set; }
        [Required]
        public string Author { get; set; }
        [Required]
        public string Type { get; set; }

        public string ImagePath { get; set; }

        [NotMapped]
        public int Quantity { get; set; }
        [NotMapped]
        public double TotalPrice { get; set; }
    }
}
