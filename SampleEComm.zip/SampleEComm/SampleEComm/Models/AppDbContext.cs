﻿using Microsoft.EntityFrameworkCore;
namespace SampleEComm.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options):base(options)
        { 
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Book> books { get; set; }
        public DbSet<Cloth> cloths { get; set; }
        public DbSet<Admin> admins { get; set; }
        public DbSet<Transaction> transactions { get; set; }

    }
}
