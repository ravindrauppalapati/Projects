﻿using System.ComponentModel.DataAnnotations;

namespace SampleEComm.Models
{
    public class Transaction
    {
        public int Id { get; set; }

        public string BookId { get; set; }
        public string ClothId { get; set; }
        public string BookQuantity { get; set; }
        public string ClothQuantity { get; set; }

        public double TotalPrice { get; set; }
        public int UserId { get; set; }

        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime Date { get; set; }

    }
}
