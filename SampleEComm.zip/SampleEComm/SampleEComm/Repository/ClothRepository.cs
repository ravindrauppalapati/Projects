﻿using Microsoft.EntityFrameworkCore;
using SampleEComm.Models;

namespace SampleEComm.Repository
{
    public class ClothRepository : IClothRepository
    {
        private readonly AppDbContext _context;
        public ClothRepository(AppDbContext context)
        {
            _context = context;
        }
        public async Task DeleteCloth(int Id)
        {
            var cloth = await _context.cloths.FindAsync(Id);
            _context.cloths.Remove(cloth);
        }

        public  async Task<Cloth?> GetClothbyId(int Id)
        {
            return await _context.cloths.FindAsync(Id);
        }

        public async Task<IEnumerable<Cloth>> GetClothsAll()
        {
            return await _context.cloths.ToListAsync();
        }

        public async Task InsertCloth(Cloth cloth)
        {
           await _context.cloths.AddAsync(cloth);
        }

        public async Task SaveChanges()
        {
           await _context.SaveChangesAsync();
        }

        public async Task UpdateCloth(Cloth cloth)
        {
            _context.cloths.Update(cloth);
        }
    }
}
