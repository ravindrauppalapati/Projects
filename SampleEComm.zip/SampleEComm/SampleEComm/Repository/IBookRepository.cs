﻿using SampleEComm.Models;

namespace SampleEComm.Repository
{
    public interface IBookRepository
    {
        public Task InsertBook(Book book);
        public Task UpdateBook(Book book);
        public Task DeleteBook(int Id); 
        public Task<Book> GetBookbyId(int Id);
        public Task<IEnumerable<Book>> GetBooksAll();

        public Task SaveChanges();


    }
}
