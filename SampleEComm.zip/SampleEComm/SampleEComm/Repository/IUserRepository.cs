﻿using SampleEComm.Models;

namespace SampleEComm.Repository
{
    public interface IUserRepository
    {
        Task<User> LoginValidate(string username, string password);

        Task RegistrationValidate(User user);

        Task<List<User>> TopUsers();

        Task<List<Transaction>> ReturnTransaction();
    }
}
