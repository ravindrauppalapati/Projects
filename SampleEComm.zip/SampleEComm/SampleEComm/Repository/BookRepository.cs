﻿using Microsoft.EntityFrameworkCore;
using SampleEComm.Models;

namespace SampleEComm.Repository
{
    public class BookRepository : IBookRepository
    {
        private readonly AppDbContext _context;
        public BookRepository(AppDbContext context)
        {
            _context = context;
        }
        public async Task DeleteBook(int Id)
        {
            var book =await _context.books.FindAsync(Id);
            _context.books.Remove(book);
            
        }

        public async Task<Book> GetBookbyId(int Id)
        {
            return await _context.books.FindAsync(Id);
        }

        public async Task<IEnumerable<Book>> GetBooksAll()
        {
            return await _context.books.ToListAsync();
        }

        public async Task InsertBook(Book book)
        {
          await _context.books.AddAsync(book);
        }

        public async Task SaveChanges()
        {
           await _context.SaveChangesAsync();
        }

        public async Task UpdateBook(Book book)
        {
               _context.books.Update(book);
        }
    }
}
