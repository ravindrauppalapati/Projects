﻿using SampleEComm.Models;

namespace SampleEComm.Repository
{
    public interface IClothRepository
    {
        public Task InsertCloth(Cloth cloth);
        public Task UpdateCloth(Cloth cloth);
        public Task DeleteCloth(int Id);
        public Task<Cloth> GetClothbyId(int Id);
        public Task<IEnumerable<Cloth>> GetClothsAll();

        public Task SaveChanges();
    }
}
