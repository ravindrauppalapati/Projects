﻿using Microsoft.EntityFrameworkCore;
using SampleEComm.Models;
using System.Collections.Generic;
using System.Collections.Immutable;

namespace SampleEComm.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly AppDbContext _context;
        public UserRepository(AppDbContext context)
        {
            _context = context;
        }
        public async  Task<User> LoginValidate(string username, string password)
        {
            var user =  _context.Users.SingleOrDefault(u => u.UserName == username &&  u.Password == password);
            return user;
        }

        public async Task RegistrationValidate(User user)
        {
            var username =  _context.Users.SingleOrDefault(u => u.UserName == user.UserName);
            var Email = _context.Users.SingleOrDefault(u => u.Email == user.Email);
            var admin = _context.admins.SingleOrDefault(u => u.UserName == user.UserName);
            if (username == null && Email == null && admin == null)
            {
                 _context.Users.Add(user);
                _context.SaveChanges();
                
            }
        }

        public async Task<List<Transaction>> ReturnTransaction()
        {
            return _context.transactions.ToList();
        }

        public async Task<List<User>> TopUsers()
        {
            var res = (from i in _context.Users
                       orderby i.TotalSpent descending
                       select i).Take(5);
           
            List < User > users =res.ToList();

            return users;
            
        }
    }
}
