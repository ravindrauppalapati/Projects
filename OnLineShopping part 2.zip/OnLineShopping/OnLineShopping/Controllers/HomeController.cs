using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnLineShopping.Data;
using OnLineShopping.Models;
using OnLineShopping.Utility;
using System.Diagnostics;

namespace OnLineShopping.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _context;
        public HomeController(ILogger<HomeController> logger,ApplicationDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            return View(_context.Products.Include(c => c.ProductTypes).Include(f=>f.SpecialTags).ToList());
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public IActionResult Details(int Id)
        {
            ViewBag.ProductType = _context.ProductTypes.ToList();
            ViewBag.SpecialTag = _context.SpecialTags.ToList();
            if (Id == null) return NotFound();
            var prod = _context.Products.Find(Id);
            if (prod == null) return NotFound();
            return View(prod);
        }
        [HttpPost]
        [ActionName("Details")]
        public IActionResult ProductDetails(int Id)
        {
            List<Product> products = new List<Product>();

            var prod = _context.Products.Include(c=> c.ProductTypes).FirstOrDefault(c=>c.Id == Id);
             products = HttpContext.Session.Get<List<Product>>("Products");
            if (products == null)
            {
                products = new List<Product>();
            }
            products.Add(prod);
            HttpContext.Session.Set("Products", products);
            return RedirectToAction("Index");
        }
        public IActionResult Cart()
        {
            List<Product> products = HttpContext.Session.Get<List<Product>>("Products");
            if(products == null)
            {  products = new List<Product>(); }
            return View(products);
        }
        public IActionResult Remove(int Id)
        {
            List<Product> products = HttpContext.Session.Get<List<Product>>("Products");
            if (products != null)
            {
                var product = products.FirstOrDefault(p => p.Id == Id);

                if (product != null)
                {
                    products.Remove(product);
                    HttpContext.Session.Set("Products", products);
                }
            }
            return RedirectToAction("Index");
        }
    }
}
