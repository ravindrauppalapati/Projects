﻿using Microsoft.AspNetCore.Mvc;
using OnLineShopping.Data;
using OnLineShopping.Models;

namespace OnLineShopping.Controllers
{
    public class ProductTypeController : Controller
    {
        private readonly ApplicationDbContext _context;
        public ProductTypeController(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View(_context.ProductTypes.ToList());
        }

        [HttpGet]
        public IActionResult Create()
        {   
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ProductType type)
        {
            if (ModelState.IsValid)
            {
                _context.ProductTypes.Add(type);
                await _context.SaveChangesAsync();

                return RedirectToAction("Index");
            }
            return View(type);
        }
        [HttpGet]
        public IActionResult Edit(int Id)
        {
            if (Id == null)
            {
                return NotFound();
            }

            var type = _context.ProductTypes.Find(Id);
            if (type == null)
            {
                return NotFound();
            }
            return View(type);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(ProductType type)
        {
            if (ModelState.IsValid) {
              _context.Update(type);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(type);
        }
        [HttpGet]
        public IActionResult Delete(int Id)
        {
            if (Id == null)
            {
                return NotFound();
            }

            var type = _context.ProductTypes.Find(Id);
            if (type == null)
            {
                return NotFound();
            }
            return View(type);
        }

        [HttpPost]
        public  IActionResult  DeleteConfirmed(int Id)
        {
            var type = _context.ProductTypes.Find(Id);
             _context.Remove(type);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Details(int Id)
        {
            var type = _context.ProductTypes.Find(Id);
            return View(type);
        }
    }
}
