﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnLineShopping.Models;

namespace OnLineShopping.Controllers
{
    public class AdministrationController : Controller
    { 
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly UserManager<IdentityUser> _userManager;
        public AdministrationController(RoleManager<IdentityRole> roleManager, UserManager<IdentityUser> userManager)
        {
            _roleManager = roleManager;
            _userManager = userManager;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public IActionResult CreateRole()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> CreateRole(RoleViewModel model)
        {
            if (ModelState.IsValid)
            {
                bool isExists = await _roleManager.RoleExistsAsync(model.RoleName);
                if (isExists)
                {
                    ModelState.AddModelError("", "Role Already Exists");
                }
                else 
                { 
                    var role = new IdentityRole { Name = model.RoleName }; 
                    var result = await _roleManager.CreateAsync(role);
                    if (result.Succeeded)
                    {
                        return RedirectToAction("Index","Home");
                    }
                    foreach (var error in result.Errors) {
                        ModelState.AddModelError("",error.Description);
                    }
                }
            }
            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> ListRoles()
        {
            var roles = await _roleManager.Roles.ToListAsync();
            return View(roles);
        }

        [HttpGet]
        public async Task<IActionResult> EditRole(string Id)
        {
            var role =await _roleManager.FindByIdAsync(Id);

            if(role == null) return View("Error");

            var model = new EditRoleViewModel
            {
                Id= role.Id,
                RoleName = role.Name,
                users = new List<string>() 
            };
            foreach (var user in _userManager.Users.ToList())
            {
                if (await _userManager.IsInRoleAsync(user, role.Name))
                {
                    model.users.Add(user.UserName);
                }
            }
            return View(model);  
        }

        [HttpGet]
        public async Task<IActionResult> EditUsersInRole(string Id)
        {
            ViewBag.Id = Id;

            var role = await _roleManager.FindByIdAsync(Id);
            if(role == null) return View("NotFound");

            ViewBag.Name = role.Name;

            var model = new List<UserRoleViewModel>();

            foreach (var user in _userManager.Users.ToList())
            {
                var usermodel = new UserRoleViewModel
                {
                    UserId = user.Id,
                    UserName = user.UserName
                };
                if (await _userManager.IsInRoleAsync(user, role.Name))
                {
                    usermodel.IsSelected = true;
                }
                else 
                {
                    usermodel.IsSelected= false;
                }
                model.Add(usermodel);
            }
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> EditUsersInRole(List<UserRoleViewModel> model, string Id)
        { 
            var role = await _roleManager.FindByIdAsync(Id);

            if (role == null)
            { 
                return View("NotFound");
            }

            for (int i = 0; i < model.Count; i++)
            {
                var user = await _userManager.FindByIdAsync(model[i].UserId);

                IdentityResult? result;

                if (model[i].IsSelected && !(await _userManager.IsInRoleAsync(user, role.Name)))
                { 
                    result = await _userManager.AddToRoleAsync(user, role.Name);
                }
                else if (!model[i].IsSelected && await _userManager.IsInRoleAsync(user, role.Name))
                { 
                    result = await _userManager.RemoveFromRoleAsync(user, role.Name);
                }
                else
                { 
                    continue;
                }
 
                if (result.Succeeded)
                {
                    if (i < (model.Count - 1))
                        continue;
                    else
                        return RedirectToAction("EditRole", new { Id = Id });
                }
            }

            return RedirectToAction("EditRole", new { Id = Id });
        }
    }
}
