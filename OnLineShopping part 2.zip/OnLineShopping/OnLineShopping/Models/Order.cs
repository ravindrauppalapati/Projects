﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.Design;

namespace OnLineShopping.Models
{
    public class Order
    {
        public Order()
        {
            orderDetails = new List<OrderDetails>();
        }
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Display(Name ="Order No")]
        public string OrderNo { get; set; }
        public string Name { get; set; }
        [Display(Name = "Phone No")]
        public string PhoneNo { get; set; }
        [EmailAddress]
        public string Email { get; set; }
        public string Address { get; set; }
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime OrderDate { get; set; }

        public virtual List<OrderDetails> orderDetails { get; set; }
    }
}
