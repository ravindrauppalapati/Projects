﻿using System.ComponentModel.DataAnnotations;

namespace OnLineShopping.Models
{
    public class EditRoleViewModel
    { 
        [Key]
        public string Id { get; set; }
        [Required]
        public string RoleName { get; set; }

        public List<string> users { get; set; }
    }
}
