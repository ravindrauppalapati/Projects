﻿using System.ComponentModel.DataAnnotations;

namespace OnLineShopping.Models
{
    public class RegisterViewModel
    {
        [Required]
        [EmailAddress]
        [Key]
        public string Email { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string  Password{ get; set; }
       
        [DataType(DataType.Password)]
        [Compare("Password",ErrorMessage ="Password Mismatched")]
        [Display(Name ="Confirm Password")]
        public string  ConfirmPassword{ get; set; }

    }
}
