﻿using EmployeePortalApp.Models;
using EmployeePortalApp.Service;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace EmployeePortalApp.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly EmployeeService _employeeService;
        public EmployeeController()
        {
            _employeeService = new EmployeeService();
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public async Task<IActionResult> List([FromQuery] string searchItem, [FromQuery] string selectedDepartment,
           [FromQuery] string selectedType, [FromQuery] int PageNumber = 1, [FromQuery] int pageSize = 5)
        {
          var (employees , count) =  await _employeeService.getEmployees(searchItem,selectedDepartment,selectedType, PageNumber, pageSize);

            var model = new EmployeeListViewModel
            {
                Employees =employees,
                PageNumber = PageNumber,
                PageSize = pageSize,
                TotalPages=(int) Math.Ceiling((double)count/pageSize),
                SearchItem =searchItem,
                SelectedDepartment =selectedDepartment,
                SelectedType =selectedType
            };
            GetSelectLists();
            ViewBag.PageSize = new SelectList(new List<int> {3,5,10,15,20});
            return View(model);
        }

        [HttpGet]
        public IActionResult Create()
        {
            GetSelectLists();
            return View();
        }
        [HttpPost]
        public IActionResult Create([FromFormAttribute] Employee employee)
        {
            if (ModelState.IsValid)
            {
                _employeeService.CreateEmployee(employee);
                return RedirectToAction("Success",new {id = employee.Id});
            }
            GetSelectLists();
            return View(employee);
        }

        public IActionResult Success()
        {
            //var emp = _employeeService.getEmployeeById(id);
            //if(emp == null)
            //    return NotFound();
            return View();
        }

        public IActionResult Details([FromRoute] int id)
        {
            var emp = _employeeService.getEmployeeById(id);
            if (emp == null)
                return NotFound();
            return View(emp);
        }

        [HttpGet]
        public IActionResult Update([FromRoute] int id)
        {
            var emp = _employeeService.getEmployeeById(id);
            if (emp == null)
                return NotFound();
            GetSelectLists();
            return View(emp);
        }

        [HttpPost]
        public IActionResult Update([FromForm] Employee employee)
        {
            if (ModelState.IsValid)
            {
                _employeeService.updateEmployee(employee);
                TempData["Message"] = $"Employee : {employee.Id} has been updated";
                return RedirectToAction("List");
            }
            GetSelectLists();
            return View(employee);
        }
        [HttpGet]
        public IActionResult Delete([FromRoute] int id)
        {
            var emp = _employeeService.getEmployeeById(id);
            if (emp == null)
                return NotFound();
            return View(emp);
        }
        [HttpPost,ActionName("Delete")]
        public   IActionResult DeleteConfirmed([FromRoute] int id)
        {
            var emp =  _employeeService.getEmployeeById(id);
            if(emp == null)
                return NotFound();
            _employeeService.deleteEmployee(id);
            TempData["Message"] = $"Employee : {id} has been deleted";
            return RedirectToAction("List");
        }

        [HttpGet]
        public JsonResult getPositions(Department department)
        {
            var positions = new Dictionary<Department, List<string>>
            {
                { Department.IT, new List<string> { "Software Developer", "System Administrator", "Network Engineer" } },
                { Department.HR, new List<string> { "HR Specialist", "HR Manager", "Talent Acquisition Coordinator" } },
                { Department.Sales, new List<string> { "Sales Executive", "Sales Manager", "Account Executive" } },
                { Department.Admin, new List<string> { "Office Manager", "Executive Assistant", "Receptionist" } }
            };
            var result = positions.ContainsKey(department) ? positions[department] : new List<string>();
            return Json(result);
        }
        private void GetSelectLists()
        {
            ViewBag.DepartmentOptions = new SelectList(Enum.GetValues(typeof(Department)).Cast<Department>());
            ViewBag.EmployeeTypeOptions = new SelectList(Enum.GetValues(typeof(EmployeeType)).Cast<EmployeeType>());
        }
    }
}
