﻿using EmployeePortalApp.Models;
using System.Collections.Specialized;

namespace EmployeePortalApp.Service
{
    public class EmployeeService
    {
        private List<Employee> _employees = new List<Employee>()
        {
            new Employee { Id = 1, FullName = "John Doe", Email = "john@example.com", Position = "Software Developer", Department = Department.IT, HireDate = DateTime.Now.AddYears(-3), DateOfBirth = DateTime.Now.AddYears(-30), Type = EmployeeType.Permanent, Gender = "Male", Salary = 60000 },
            new Employee { Id = 2, FullName = "Jane Smith", Email = "jane@example.com", Position = "HR Manager", Department = Department.HR, HireDate = DateTime.Now.AddYears(-5), DateOfBirth = DateTime.Now.AddYears(-35), Type = EmployeeType.Permanent, Gender = "Female", Salary = 80000 },
            new Employee { Id = 3, FullName = "Sam Wilson", Email = "sam@example.com", Position = "Sales Executive", Department = Department.Sales, HireDate = DateTime.Now.AddYears(-2), DateOfBirth = DateTime.Now.AddYears(-28), Type = EmployeeType.Contract, Gender ="Male", Salary = 50000 },
            new Employee { Id = 4, FullName = "Anna Taylor", Email = "anna@example.com", Position = "Executive Assistant", Department = Department.Admin, HireDate = DateTime.Now.AddYears(-1), DateOfBirth = DateTime.Now.AddYears(-25), Type = EmployeeType.Temporary, Gender = "Female", Salary = 40000 },
            new Employee { Id = 5, FullName = "Tom Brown", Email = "tom@example.com", Position = "Network Engineer", Department = Department.IT, HireDate = DateTime.Now.AddYears(-4), DateOfBirth = DateTime.Now.AddYears(-32), Type = EmployeeType.Permanent, Gender = "Male", Salary = 70000 },
            new Employee { Id = 6, FullName = "Emma Davis", Email = "emma@example.com", Position = "HR Specialist", Department = Department.HR, HireDate = DateTime.Now.AddYears(-6), DateOfBirth = DateTime.Now.AddYears(-34), Type = EmployeeType.Permanent, Gender = "Female", Salary = 75000 },
            new Employee { Id = 7, FullName = "Luke Miller", Email = "luke@example.com", Position = "Sales Manager", Department = Department.Sales, HireDate = DateTime.Now.AddYears(-3), DateOfBirth = DateTime.Now.AddYears(-31), Type = EmployeeType.Contract, Gender = "Male", Salary = 85000 },
            new Employee { Id = 8, FullName = "Olivia Johnson", Email = "olivia@example.com", Position = "Office Manager", Department = Department.Admin, HireDate = DateTime.Now.AddYears(-2), DateOfBirth = DateTime.Now.AddYears(-29), Type = EmployeeType.Permanent, Gender = "Female", Salary = 65000 },
            new Employee { Id = 9, FullName = "Mia Moore", Email = "mia@example.com", Position = "System Administrator", Department = Department.IT, HireDate = DateTime.Now.AddYears(-1), DateOfBirth = DateTime.Now.AddYears(-26), Type = EmployeeType.Intern, Gender = "Female", Salary = 30000 },
            new Employee { Id = 10, FullName = "Chris Evans", Email = "chris@example.com", Position = "Talent Acquisition Coordinator", Department = Department.HR, HireDate = DateTime.Now.AddYears(-5), DateOfBirth = DateTime.Now.AddYears(-33), Type = EmployeeType.Temporary, Gender = "Other", Salary = 55000 },
            new Employee { Id = 11, FullName = "Sophia White", Email = "sophia@example.com", Position = "Sales Executive", Department = Department.Sales, HireDate = DateTime.Now.AddYears(-2), DateOfBirth = DateTime.Now.AddYears(-27), Type = EmployeeType.Permanent, Gender = "Female", Salary = 52000 },
            new Employee { Id = 12, FullName = "Liam Green", Email = "liam@example.com", Position = "Receptionist", Department = Department.Admin, HireDate = DateTime.Now.AddYears(-1), DateOfBirth = DateTime.Now.AddYears(-24), Type = EmployeeType.Temporary, Gender = "Male", Salary = 38000 },
            new Employee { Id = 13, FullName = "Noah Black", Email = "noah@example.com", Position = "System Administrator", Department = Department.IT, HireDate = DateTime.Now.AddYears(-3), DateOfBirth = DateTime.Now.AddYears(-29), Type = EmployeeType.Permanent, Gender = "Male", Salary = 65000 },
            new Employee { Id = 14, FullName = "Isabella Blue", Email = "isabella@example.com", Position = "HR Specialist", Department = Department.HR, HireDate = DateTime.Now.AddYears(-4), DateOfBirth = DateTime.Now.AddYears(-30), Type = EmployeeType.Permanent, Gender = "Female", Salary = 76000 },
            new Employee { Id = 15, FullName = "James Brown", Email = "james@example.com", Position = "Account Executive", Department = Department.Sales, HireDate = DateTime.Now.AddYears(-2), DateOfBirth = DateTime.Now.AddYears(-28), Type = EmployeeType.Contract, Gender = "Male", Salary = 62000 }

        };

        public async Task<(List<Employee> emp, int totalCount)> getEmployees(string searchItem, string selectedDepartment,
            string selectedType, int pageNumber, int PageSize)
        {
            var employees = _employees.AsQueryable();
            if (!string.IsNullOrEmpty(searchItem))
            {
                employees = employees.Where(x => x.FullName.Contains(searchItem, StringComparison.OrdinalIgnoreCase));
            }
            if (!string.IsNullOrEmpty(selectedDepartment))
            {
                if (Enum.TryParse(selectedDepartment, out Department department))
                {
                    employees = employees.Where(x => x.Department == department);
                }
            }

            if (!string.IsNullOrEmpty(selectedType))
            {
                if (Enum.TryParse(selectedType, out EmployeeType type))
                {
                    employees = employees.Where(x => x.Type == type);
                }
            }

            int count = employees.Count();

            employees = employees.Skip((pageNumber - 1) * PageSize).Take(PageSize);

            return await Task.FromResult((employees.ToList(), count));
        }

        public Employee? getEmployeeById(int Id)
        {
            return _employees.FirstOrDefault(x => x.Id == Id);
        }

        public void CreateEmployee(Employee employee)
        {
            employee.Id = _employees.Max(x => x.Id) + 1;
            _employees.Add(employee);
        }
        public void updateEmployee(Employee employee)
        {
            var emp = getEmployeeById(employee.Id);

            if (emp != null)
            {
                emp.FullName =employee.FullName;
                emp.Email =employee.Email;
                emp.Position =employee.Position;
                emp.Department =employee.Department;
                emp.HireDate =employee.HireDate;
                emp.DateOfBirth =employee.DateOfBirth;
                emp.Type =employee.Type;
                emp.Gender =employee.Gender;
                emp.Salary =employee.Salary;
            }
        }

        public void deleteEmployee(int Id)
        {
            var emp = getEmployeeById(Id);
            if(emp != null)
            {
                _employees.Remove(emp);
            }
        }
    }
}
