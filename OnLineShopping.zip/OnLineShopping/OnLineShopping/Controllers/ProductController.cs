﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnLineShopping.Data;
using OnLineShopping.Models; 

namespace OnLineShopping.Controllers
{
    public class ProductController : Controller
    {
        private readonly ApplicationDbContext _context;
        public ProductController(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View(_context.Products.Include(c=>c.ProductTypes).Include(f=>f.SpecialTags));
        }
        [HttpPost]
        public IActionResult Index(string txtName)
        {
            ViewBag.ProductType = _context.ProductTypes.ToList();
            ViewBag.SpecialTag = _context.SpecialTags.ToList();
            var res = _context.Products.Where(p => p.ProductName.Trim().ToLower().Contains(txtName.Trim().ToLower()));
            return View(res);
        }
        [HttpGet]
        public IActionResult Create()
        {
            ViewBag.ProductType = _context.ProductTypes.ToList();
            ViewBag.SpecialTag = _context.SpecialTags.ToList();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Product prod,IFormFile Image)
        {
            prod.ImageUrl = Image.FileName;
            ViewBag.Name = Image.FileName;
            if (Image != null)
            {
                var filepath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads", Image.FileName);
                using (var stream = System.IO.File.Create(filepath))
                {
                    Image.CopyTo(stream);
                }
            }

            _context.Products.Add(prod);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult Edit(int Id)
        {
            ViewBag.ProductType = _context.ProductTypes.ToList();
            ViewBag.SpecialTag = _context.SpecialTags.ToList(); 
            var product = _context.Products.Include(c => c.ProductTypes).Include(f=>f.SpecialTags).FirstOrDefault(c=> c.Id == Id);
            if(product == null)
                return NotFound();
            ViewBag.Image = product.ImageUrl;
            return View(product);
        }
        [HttpPost]
        public async Task<IActionResult> Edit(Product prod, IFormFile Image)
        {
            prod.ImageUrl = Image.FileName;
            ViewBag.Name = Image.FileName;
            if (Image != null)
            {
                var filepath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads", Image.FileName);
                using (var stream = System.IO.File.Create(filepath))
                {
                    Image.CopyTo(stream);
                }
            }

            _context.Products.Update(prod);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult Delete(int Id)
        {
            ViewBag.ProductType = _context.ProductTypes.ToList();
            ViewBag.SpecialTag = _context.SpecialTags.ToList();
            var prod= _context.Products.Find(Id);
            return View(prod);
        }
        [HttpPost]
        public IActionResult DeleteConfirmed(int Id)
        {
            var prod = _context.Products.Find(Id);
            _context.Products.Remove(prod);
            _context.SaveChanges();

            return RedirectToAction("Index");

        }

        public IActionResult Details(int Id)
        {
            ViewBag.ProductType = _context.ProductTypes.ToList();
            ViewBag.SpecialTag = _context.SpecialTags.ToList();
            var prod = _context.Products.Find(Id);
            return View(prod);
        }
    }
}
