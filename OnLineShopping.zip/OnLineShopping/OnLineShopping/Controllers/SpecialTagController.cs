﻿using Microsoft.AspNetCore.Mvc;
using OnLineShopping.Data;
using OnLineShopping.Models;

namespace OnLineShopping.Controllers
{
    public class SpecialTagController : Controller
    {
        private readonly ApplicationDbContext _context;
        public SpecialTagController(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View(_context.SpecialTags.ToList());
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(SpecialTag tag)
        {
            if (ModelState.IsValid)
            {
                _context.SpecialTags.Add(tag);
                await _context.SaveChangesAsync();

                return RedirectToAction("Index");
            }
            return View(tag);
        }

        [HttpGet]
        public IActionResult Edit(int Id)
        {
            if (Id == null)
            {
                return NotFound();
            }

            var tag = _context.SpecialTags.Find(Id);
            if (tag == null)
            {
                return NotFound();
            }
            return View(tag);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(SpecialTag tag)
        {
            if (ModelState.IsValid)
            {
                _context.Update(tag);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(tag);
        }
        [HttpGet]
        public IActionResult Delete(int Id)
        {
            if (Id == null)
            {
                return NotFound();
            }

            var tag = _context.SpecialTags.Find(Id);
            if (tag == null)
            {
                return NotFound();
            }
            return View(tag);
        }

        [HttpPost]
        public IActionResult DeleteConfirmed(int Id)
        {
            var tag = _context.SpecialTags.Find(Id);
            _context.Remove(tag);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Details(int Id)
        {
            var tag = _context.SpecialTags.Find(Id);
            return View(tag);
        }
    }
}
