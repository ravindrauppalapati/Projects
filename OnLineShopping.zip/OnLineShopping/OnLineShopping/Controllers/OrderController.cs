﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnLineShopping.Data;
using OnLineShopping.Models;
using OnLineShopping.Utility;

namespace OnLineShopping.Controllers
{
    public class OrderController : Controller
    {
        private readonly ApplicationDbContext _context;
        public OrderController(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public IActionResult CheckOut()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> CheckOut(Order ord)
        {
            List<Product> products = HttpContext.Session.Get<List<Product>>("Products");
            if (products != null)
            {  
                foreach (var prod in products)
                {
                    OrderDetails details = new OrderDetails();
                    details.ProductId = prod.Id;
                    ord.orderDetails.Add(details);
                }
                ord.OrderNo = getOrderNo(); 
                _context.Orders.Add(ord);
                 _context.SaveChanges(); 
                HttpContext.Session.Clear(); 
            }
            return RedirectToAction("Index","Home");
        }

        public string getOrderNo()
        {
            int rowCount = _context.Orders.ToList().Count + 1;
            return rowCount.ToString("000");
        }
    }
}
