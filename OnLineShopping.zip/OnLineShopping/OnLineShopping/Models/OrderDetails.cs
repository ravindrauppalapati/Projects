﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OnLineShopping.Models
{
    public class OrderDetails
    {
        
        public int Id { get; set; }
        public int OrderId { get; set; }
        public int ProductId { get; set; }
        [ForeignKey("OrderId")]
        public Order orders { get; set; }
        [ForeignKey("ProductId")]
        public Product products { get; set; }
    }
}
