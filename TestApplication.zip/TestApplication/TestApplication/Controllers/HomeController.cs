using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using TestApplication.Models;

namespace TestApplication.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly AppDbContext _Context;
        public HomeController(ILogger<HomeController> logger, AppDbContext context)
        {
            _logger = logger;
            _Context = context;
        }

        public IActionResult EmployeeList()
        {
            var emp = _Context.Employees.ToList();
            return PartialView("_EmployeeList", emp);
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Create(Employee emp, IFormFile Image)
        {
            emp.ImageURL = Image.FileName;
            if (Image != null && Image.Length > 0)
            {
                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/Uploads", Image.FileName);
                using (var stream = System.IO.File.Create(filePath))
                {
                    Image.CopyTo(stream);
                }
            }
            _Context.Database.ExecuteSqlInterpolated($"Exec usp_Insert_Employee {emp.EmployeeName},{emp.PhoneNumber},{emp.DOB},{emp.Gender},{emp.Qualification},{emp.ImageURL},{emp.EmailId}");

            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult Edit(int Id)
        {
            var emp = _Context.Employees.Find(Id);
            return View(emp);
        }
        [HttpPost]
        public IActionResult Edit(Employee emp, IFormFile Image)
        {
            emp.ImageURL = Image.FileName;
            if (Image != null && Image.Length > 0)
            {
                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/Uploads", Image.FileName);
                using (var stream = System.IO.File.Create(filePath))
                {
                    Image.CopyTo(stream);
                }
            }
            _Context.Database.ExecuteSqlInterpolated($"Exec usp_Update_Employee {emp.Id}, {emp.EmployeeName},{emp.PhoneNumber},{emp.DOB},{emp.Gender},{emp.Qualification},{emp.ImageURL},{emp.EmailId}");

            return RedirectToAction("Index");
        }

        public IActionResult Details(int Id)
        {
            var emp = _Context.Employees.Find(Id);
            return View(emp);
        }

        public IActionResult Delete(int Id)
        {
            var emp = _Context.Employees.Find(Id);
            return View(emp);
        }
        [HttpPost]
        public IActionResult DeleteConfirmed(int Id)
        {
            var emp = _Context.Employees.Find(Id);
            _Context.Employees.Remove(emp);
            _Context.SaveChanges();
            return View("Index");
        }
        
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
