﻿using Microsoft.AspNetCore.Authorization;
using System.ComponentModel.DataAnnotations;

namespace TestApplication.Models
{
    public class CustomValidateDate
    {
        [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
        public sealed class ValidBirthDate : ValidationAttribute
        {
            protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
            {
                if (value != null)
                {
                    DateTime _birthDate = Convert.ToDateTime(value);
                    if (_birthDate > DateTime.Now)
                    {
                        return new ValidationResult("BirthDate can not be greater than current Date");
                    }
                   
                }
                return ValidationResult.Success;
            }
        }
    }
}
