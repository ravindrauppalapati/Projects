﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Net;

namespace ECommWEBAPI.Models
{
    public class APIResponse<T>
    {
        public bool success { get; set; }
        public HttpStatusCode StatusCode { get; set; }
        public string Message { get; set; }
        public T Data { get; set; }
        public object Error { get; set; }

        public APIResponse(T data,string message="",HttpStatusCode statusCode = HttpStatusCode.OK)
        {
           this.success = true;
           this.StatusCode = statusCode;
            this.Message = message;
           this.Data = data;
            this.Error = null;
        }
        public APIResponse(HttpStatusCode statusCode,string message,object error = null)
        {
            this.success = false;
            this.StatusCode = statusCode;
            this.Message = message;
            this.Data = default(T);
            this.Error = error;
        }

    }
}
