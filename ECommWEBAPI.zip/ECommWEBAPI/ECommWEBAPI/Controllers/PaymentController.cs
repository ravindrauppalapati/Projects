﻿using Azure;
using ECommWEBAPI.DTOs;
using ECommWEBAPI.Models;
using ECommWEBAPI.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ECommWEBAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        private readonly PaymentRepository _PaymentRepo;
        public PaymentController(PaymentRepository paymentRepository)
        {
            _PaymentRepo = paymentRepository;
        }

        [HttpPost("MakePayment")]
        public async Task<APIResponse<PaymentResponseDTO>> MakePayment([FromBody] PaymentDTO payment)
        {
            if (!ModelState.IsValid)
            {
                return new APIResponse<PaymentResponseDTO>(System.Net.HttpStatusCode.BadRequest, "Invalid Data", ModelState);
            }
            try
            {
                var response = await _PaymentRepo.makePaymentAsync(payment);
                return new APIResponse<PaymentResponseDTO>(response, response.Message);
            }
            catch (Exception ex)
            {
                return new APIResponse<PaymentResponseDTO>(System.Net.HttpStatusCode.InternalServerError, ex.Message);

            }
        }

        [HttpGet("paymentDetails/{id}")]
        public async Task<APIResponse<Payment>> GetPaymentDetails(int id)
        {
            try
            {
                var payment = await _PaymentRepo.getPaymentDetailsAsync(id);

                if (payment == null)
                    return new APIResponse<Payment>(System.Net.HttpStatusCode.NotFound, "Payment Not Found");
                return new APIResponse<Payment>(payment, "Payment retrieved Successfully");
            }
            catch (Exception ex)
            {
                return new APIResponse<Payment>(System.Net.HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpPut("UpdatePaymentStatus/{id}")]
        public async Task<APIResponse<UpdatePaymentResponseDTO>> UpdatePaymentStatus(int id, [FromBody] PaymentStatusDTO payment)
        {
            if (!ModelState.IsValid)
            {
                return new APIResponse<UpdatePaymentResponseDTO>(System.Net.HttpStatusCode.BadRequest, "Invalid Data", ModelState);
                
            }

            if (id != payment.PaymentId)
            {
                return new APIResponse<UpdatePaymentResponseDTO>(System.Net.HttpStatusCode.BadRequest, "Mismatched ID"); 
            }
            try
            {
                var response = await _PaymentRepo.UpdatePaymentStatusAsync(id, payment.Status);
                return new APIResponse<UpdatePaymentResponseDTO>(response, response.Message);
            }
            catch (Exception ex)
            {
                return new APIResponse<UpdatePaymentResponseDTO>(System.Net.HttpStatusCode.InternalServerError, ex.Message);
            }
        }

    }
}
