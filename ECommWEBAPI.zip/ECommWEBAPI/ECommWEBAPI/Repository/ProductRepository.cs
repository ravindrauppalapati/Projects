﻿using ECommWEBAPI.DTOs;
using ECommWEBAPI.Models;
using Microsoft.Data.SqlClient;

namespace ECommWEBAPI.Repository
{
    public class ProductRepository
    {
        private readonly SqlConnectionFactory _factory;
        public ProductRepository(SqlConnectionFactory factory)
        {
            _factory = factory;
        }

        public async Task<List<Product>> getAllProductsAsync()
        {
            var products = new List<Product>();
            var Query = "select ProductId,Name,Price,Quantity,Description,IsDeleted from Products where IsDeleted = 0 ";

            using (var connection = _factory.CreateConnection())
            {
                await connection.OpenAsync();

                using (var command = new SqlCommand(Query, connection))
                {
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            products.Add(new Product
                            {
                                ProductId = reader.GetInt32(reader.GetOrdinal("ProductId")),
                                Name = reader.GetString(reader.GetOrdinal("Name")),
                                Price = reader.GetDecimal(reader.GetOrdinal("Price")),
                                Quantity = reader.GetInt32(reader.GetOrdinal("Quantity")),
                                Description= reader.GetString(reader.GetOrdinal("Description")),
                                IsDeleted = false
                            });
                        }
                    }
                }
            }

            return products;
        }

        public async Task<Product> getProductById(int ProductId)
        {
            var query = "select ProductId,Name,Price,Quantity,Description,IsDeleted from Products where ProductId = @ProductId and IsDeleted =0";
            Product product = null;
            using (var connection = _factory.CreateConnection())
            {
                await connection.OpenAsync();
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ProductId", ProductId);
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            product = new Product
                            {
                                ProductId = reader.GetInt32(reader.GetOrdinal("ProductId")),
                                Name = reader.GetString(reader.GetOrdinal("Name")),
                                Price = reader.GetDecimal(reader.GetOrdinal("Price")),
                                Quantity = reader.GetInt32(reader.GetOrdinal("Quantity")),
                                Description = reader.GetString(reader.GetOrdinal("Description")),
                                IsDeleted = false
                            };
                        }
                    }
                }
            }

            return product;
        }

        public async Task<int> InsertProductAsync(ProductDTO product)
        {
            var query = "Insert into products(name,Price,Quantity,Description,IsDeleted) values (@name,@Price,@Quantity,@Description,0);select CAST(SCOPE_IDENTITY AS int);";
            using (var connection = _factory.CreateConnection())
            {
                await connection.OpenAsync();
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Name", product.Name);
                    command.Parameters.AddWithValue("@Price", product.Price);
                    command.Parameters.AddWithValue("@Quantity", product.Quantity);
                    command.Parameters.AddWithValue("@Description", product.Description);

                    int ProductId = (int)await command.ExecuteScalarAsync();
                    return ProductId;
                }
            }
        }
        public async Task UpdateProductAsync(ProductDTO product)
        {
            var query = "update Products set name=@Name,Price = @Price,Quantity =@Quantity,Description = @Description where ProductId = @ProductId";
            using (var connection = _factory.CreateConnection())
            {
                await connection.OpenAsync();
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ProductId", product.ProductId);
                    command.Parameters.AddWithValue("@Name", product.Name);
                    command.Parameters.AddWithValue("@Price", product.Price);
                    command.Parameters.AddWithValue("@Quantity", product.Quantity);
                    command.Parameters.AddWithValue("@Description", product.Description);

                    await command.ExecuteNonQueryAsync();
                }
            }
        }

        public async Task DeleteProductAsync(int ProductId)
        {
            var query = "update Products set  IsDeleted = 1 where ProductId = @ProductId ";
            using (var connection = _factory.CreateConnection())
            {
                await connection.OpenAsync();
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ProductId", ProductId);


                    await command.ExecuteNonQueryAsync();
                }
            }
        }
    }
}
