﻿using System.ComponentModel.DataAnnotations;

namespace ECommWEBAPI.DTOs
{
    public class OrderDTO
    {
        [Required]
        public int CustomerId { get; set; }

        [Required]
        public List<OrderItemDetailsDTO> orderItems { get; set; }
    }
}
