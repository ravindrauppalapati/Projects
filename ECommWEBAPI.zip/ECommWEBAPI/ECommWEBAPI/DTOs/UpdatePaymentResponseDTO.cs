﻿namespace ECommWEBAPI.DTOs
{
    public class UpdatePaymentResponseDTO
    {
        public int PaymentId { get; set; }
        public string CurrentStatus { get; set; }
        public string UpdateStatus { get; set; }
        public string Message { get; set; }
        public bool IsUpdated { get; set; }
    }
}
