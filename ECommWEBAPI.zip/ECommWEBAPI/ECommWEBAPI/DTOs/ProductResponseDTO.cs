﻿namespace ECommWEBAPI.DTOs
{
    public class ProductResponseDTO
    {
        public int ProductId { get; set; }
    }
}
