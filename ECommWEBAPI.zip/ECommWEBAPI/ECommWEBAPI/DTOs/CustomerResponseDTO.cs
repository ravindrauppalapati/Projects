﻿namespace ECommWEBAPI.DTOs
{
    public class CustomerResponseDTO
    {
        public int CustomerId { get; set; }
    }
}
