﻿using ECommWEBAPI.DTOs;
using ECommWEBAPI.Models;
using Microsoft.Data.SqlClient;

namespace ECommWEBAPI.Repository
{
    public class PaymentRepository
    {
        private readonly SqlConnectionFactory _factory;
        public PaymentRepository(SqlConnectionFactory factory)
        {
            _factory = factory;
        }
        public async Task<PaymentResponseDTO> makePaymentAsync(PaymentDTO payment)
        {
            var OrderQuery = "select totalAmount from orders where orderId =@OrderId and Status='Pending'";
            var paymentQuery = "insert into payments(orderId,Amount,status,PaymentType,PaymentDate) values(@orderId,@Amount,@status,@PaymentType,@PaymentDate);SELECT CAST(SCOPE_IDENTITY() as int);";
            var UpdatepaymentQuery = "Update payments set status = @status where paymentId=@PaymentId";

            PaymentResponseDTO paymentResponseDTO = new PaymentResponseDTO();
            using (var connection = _factory.CreateConnection())
            {
                await connection.OpenAsync();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        decimal orderAmount = 0m;
                        using (var orderCommand = new SqlCommand(OrderQuery, connection, transaction))
                        {
                            orderCommand.Parameters.AddWithValue("@OrderId", payment.OrderId);
                            var result = await orderCommand.ExecuteScalarAsync();
                            if (result == null)
                            {
                                paymentResponseDTO.Message = "Order doesn't Exists";
                                return paymentResponseDTO;
                            }
                            orderAmount = (decimal)result;
                        }

                        if (orderAmount != payment.Amount)
                        {
                            paymentResponseDTO.Message = "Mismatched Amounts";
                            return paymentResponseDTO;
                        }
                        int paymentID;
                        using (var paymentCommand = new SqlCommand(paymentQuery, connection, transaction))
                        {
                            paymentCommand.Parameters.AddWithValue("@orderId", payment.OrderId);
                            paymentCommand.Parameters.AddWithValue("@Amount", payment.Amount);
                            paymentCommand.Parameters.AddWithValue("@PaymentType", payment.PaymentType);
                            paymentCommand.Parameters.AddWithValue("@PaymentDate", DateTime.Now);
                            paymentCommand.Parameters.AddWithValue("@status", "Pending");
                            paymentID = (int)await paymentCommand.ExecuteScalarAsync();
                        }
                        string PaymentStatus = SimulatePaymentGateWayInteraction(payment);

                        using (var updateCommand = new SqlCommand(UpdatepaymentQuery, connection, transaction))
                        {
                            updateCommand.Parameters.AddWithValue("@status", PaymentStatus);
                            updateCommand.Parameters.AddWithValue("@PaymentId", paymentID);

                            await updateCommand.ExecuteNonQueryAsync();
                            paymentResponseDTO.IsCreated = true;
                            paymentResponseDTO.Status = PaymentStatus;
                            paymentResponseDTO.PaymentId = paymentID;
                            paymentResponseDTO.Message = $"Payment Processed with {PaymentStatus}";
                        }
                        transaction.Commit();
                        return paymentResponseDTO;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw;
                    }

                }
            }

        }

        private string SimulatePaymentGateWayInteraction(PaymentDTO payment)
        {
            switch (payment.PaymentType)
            {
                case "COD": return "Completed";
                case "CC": return "Completed";
                case "DC": return "Failed";
                default: return "Completed";
            }
        }

        public async Task<UpdatePaymentResponseDTO> UpdatePaymentStatusAsync(int paymentId, string newStatus)
        {
            var PaymentQuery = "select p.OrderId,p.Amount,p.Status,o.status as OrderStatus from payments p inner join orders o on p.orderId  = o.orderId and p.paymentId = @paymentId";
            var updateQuery = "update payments set status=@status where paymentId=@PaymentId";
            UpdatePaymentResponseDTO updatePaymentResponseDTO = new UpdatePaymentResponseDTO()
            {
                PaymentId = paymentId,
            };
            using (var connection = _factory.CreateConnection())
            {
                await connection.OpenAsync();
                int orderid;
                decimal paymentAmount;
                string currentPaymentStatus=string.Empty, OrderStatus=string.Empty;
                using (var command = new SqlCommand(PaymentQuery, connection))
                {
                    command.Parameters.AddWithValue("@paymentId", paymentId);
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            orderid = reader.GetInt32(reader.GetOrdinal("OrderId"));
                            paymentAmount = reader.GetDecimal(reader.GetOrdinal("Amount"));
                            currentPaymentStatus = reader.GetString(reader.GetOrdinal("status"));
                            OrderStatus = reader.GetString(reader.GetOrdinal("OrderStatus"));
                            updatePaymentResponseDTO.CurrentStatus = currentPaymentStatus;
                        }
                    }

                    if (!IsValidStatus(currentPaymentStatus, newStatus, OrderStatus))
                    {
                        updatePaymentResponseDTO.IsUpdated = false;
                        updatePaymentResponseDTO.Message = $"Invalid Status";
                        return updatePaymentResponseDTO;
                    }

                    using (var updateCommand = new SqlCommand(updateQuery, connection))
                    {
                        updateCommand.Parameters.AddWithValue("@Status", newStatus);
                        updateCommand.Parameters.AddWithValue("@PaymentId", paymentId);
                        await updateCommand.ExecuteNonQueryAsync();
                        updatePaymentResponseDTO.IsUpdated= true;
                        updatePaymentResponseDTO.UpdateStatus = newStatus;
                        updatePaymentResponseDTO.Message=$"Status updated from {currentPaymentStatus} to {newStatus}";
                        return updatePaymentResponseDTO;                    }
                }
            }
        }

        private bool IsValidStatus(string currentPaymentStatus, string newStatus, string orderStatus)
        {
            if (currentPaymentStatus == "Completed" && newStatus != "Refund")
            {
                return false;
            }
            if (currentPaymentStatus == "Pending" && newStatus != "Cancelled")
            {
                return true;
            }
            if (currentPaymentStatus == "Completed" && newStatus == "Refund" && orderStatus != "Refund")
            {
                return false;

            }
            if (newStatus == "Failed" && (currentPaymentStatus == "Completed " || currentPaymentStatus == "Cancelled"))

            {
                return false;
            }
            if (newStatus == "Completed" && currentPaymentStatus == "Pending" && (orderStatus == "Shipped" || orderStatus == "Confirmed"))
            {
                return true;
            }

            return true;
        }

        public async Task<Payment> getPaymentDetailsAsync(int paymentId)
        {
            var query = "select paymentId,OrderId,Amount,Status,PaymentType,PaymentDate from pAYMENTS where paymentId=@PaymentId";
            Payment payment = null;
            using (var connection = _factory.CreateConnection())
            {
                await connection.OpenAsync();
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@PaymentId", paymentId);
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            payment = new Payment
                            {
                                PaymentId =reader.GetInt32(reader.GetOrdinal("PaymentId")),
                                OrderId = reader.GetInt32(reader.GetOrdinal("OrderId")),
                                Amount = reader.GetDecimal(reader.GetOrdinal("Amount")),
                                Status = reader.GetString(reader.GetOrdinal("Status")),
                                PaymentType = reader.GetString(reader.GetOrdinal("PaymentType")),
                                PaymentDate = reader.GetDateTime(reader.GetOrdinal("PaymentDate")) 
                            }; 
                        }
                    }
                }
            }
            return payment;
        }
    }
}
