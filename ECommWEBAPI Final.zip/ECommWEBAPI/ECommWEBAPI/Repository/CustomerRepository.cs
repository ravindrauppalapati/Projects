﻿using ECommWEBAPI.DTOs;
using ECommWEBAPI.Models;
using Microsoft.Data.SqlClient;
using Microsoft.VisualBasic;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ECommWEBAPI.Repository
{
    public class CustomerRepository
    {
        private readonly SqlConnectionFactory _factory;
        public CustomerRepository(SqlConnectionFactory factory)
        {
            _factory = factory;
        }
        public async Task<List<Customer>> getAllCustomersAsync()
        {
            var customers = new List<Customer>();
            var Query = "select customerId,Name,Email,Address from customers where IsDeleted = 0 ";
            
            using (var connection = _factory.CreateConnection())
            {
              await  connection.OpenAsync();
                using (var command = new SqlCommand(Query, connection)) 
                {
                    using (var reader =await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            customers.Add(new Customer
                            {
                                CustomerId=reader.GetInt32(reader.GetOrdinal("CustomerId")),
                                Name=reader.GetString(reader.GetOrdinal("Name")),
                                Email=reader.GetString(reader.GetOrdinal("Email")),
                                Address= reader.GetString(reader.GetOrdinal("Address")),
                                IsDeleted= false
                            });
                        }
                    }
                }
            }

            return customers;
        }

        public async Task<Customer> getCustomerById(int CustomerId)
        {
            var query = "select CustomerId,Name,Email,Address from customers where CustomerId = @CustomerId and IsDeleted =0";
            Customer customer = null;
            using (var connection = _factory.CreateConnection())
            {
                await connection.OpenAsync();
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CustomerId", CustomerId);
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            customer = new Customer {
                                CustomerId = reader.GetInt32(reader.GetOrdinal("CustomerId")),
                                Name = reader.GetString(reader.GetOrdinal("Name")),
                                Email = reader.GetString(reader.GetOrdinal("Email")),
                                Address = reader.GetString(reader.GetOrdinal("Address")),
                                IsDeleted = false
                            };
                        }
                    }
                }
            }

            return customer;
        }

        public async Task<int> InsertCustomerAsync(CustomerDTO customer)
        {
            var query = "Insert into customers(name,Email,Address,IsDeleted) values (@Name,@Email,@Address,0);SELECT CAST(SCOPE_IDENTITY() as int);";
            using (var connection = _factory.CreateConnection())
            {
                await connection.OpenAsync();
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Name", customer.Name);
                    command.Parameters.AddWithValue("@Email", customer.Email);
                    command.Parameters.AddWithValue("@Address", customer.Address);
                    int CustomerId = (int) await command.ExecuteScalarAsync(); 
                  
                    return CustomerId;
                }
            }
        }
        public async Task UpdateCustomerAsync(CustomerDTO customer)
        {
            var query = "update customers set name=@Name,Email = @Email,Address =@Address where customerId = @CustomerId ";
            using (var connection = _factory.CreateConnection())
            {
                await connection.OpenAsync();
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CustomerId", customer.CustomerId);
                    command.Parameters.AddWithValue("@Name", customer.Name);
                    command.Parameters.AddWithValue("@Email", customer.Email);
                    command.Parameters.AddWithValue("@Address", customer.Address);

                     await command.ExecuteNonQueryAsync();
                }
            }
        }

        public async Task DeleteCustomerAsync(int CustomerId)
        {
            var query = "update customers set  IsDeleted = 1 where customerId = @CustomerId ";
            using (var connection = _factory.CreateConnection())
            {
                await connection.OpenAsync();
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CustomerId", CustomerId);
                    

                    await command.ExecuteNonQueryAsync();
                }
            }
        }
    }
}
