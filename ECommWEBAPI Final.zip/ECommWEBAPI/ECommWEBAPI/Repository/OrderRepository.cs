﻿using ECommWEBAPI.DTOs;
using ECommWEBAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace ECommWEBAPI.Repository
{
    public class OrderRepository
    {
        private readonly SqlConnectionFactory _factory;
        public OrderRepository(SqlConnectionFactory factory)
        {
            _factory = factory;
        }
        public async Task<List<Order>> getAllOrdersAsync(string status)
        {
            var orders = new List<Order>();
            var Query = "select orderId,customerId,TotalAmount,orderDate,status from orders where status = @Status";

            using (var connection = _factory.CreateConnection())
            {
                await connection.OpenAsync();
                using (var command = new SqlCommand(Query, connection))
                {
                    command.Parameters.AddWithValue("@status", status);
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            orders.Add(new Order
                            {
                                OrderId = reader.GetInt32(reader.GetOrdinal("OrderId")),
                                CustomerId = reader.GetInt32(reader.GetOrdinal("CustomerId")),
                                TotalAmount = reader.GetDecimal(reader.GetOrdinal("TotalAmount")),
                                Status = reader.GetString(reader.GetOrdinal("Status")),
                                OrderDate = reader.GetDateTime(reader.GetOrdinal("OrderDate"))
                            });
                        }
                    }
                }
            }

            return orders;
        }

        public async Task<CreateOrderResponseDTO> CreateOrderAsync(OrderDTO order)
        {
            var ProdctQuery = "select ProductId,Price,Quantity from products where productId = @ProductId and IsDeleted = 0";
            var orderQuery = "insert into orders(customerId,TotalAmount,Status,OrderDate) values(@customerId,@TotalAmount,@Status,@OrderDate);SELECT CAST(SCOPE_IDENTITY() as int);";
            var itemQuery = "insert into orderitems (orderId,ProductId,Quantity,PriceAtOrder) values(@orderId,@ProductId,@Quantity,@PriceAtOrder)";
            decimal totalAmount = 0m;

            List<OrderItem> orderItems = new List<OrderItem>();
            CreateOrderResponseDTO createOrderResponseDTO = new CreateOrderResponseDTO();
            using (var connection = _factory.CreateConnection())
            {
                await connection.OpenAsync();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        foreach (OrderItemDetailsDTO item in order.orderItems)
                        {
                            using (var productCommand = new SqlCommand(ProdctQuery, connection, transaction))
                            {
                                productCommand.Parameters.AddWithValue("@ProductId", item.ProductId);
                                using (var reader = await productCommand.ExecuteReaderAsync())
                                {
                                    if (await reader.ReadAsync())
                                    {
                                        int stockQuantity = reader.GetInt32(reader.GetOrdinal("Quantity"));
                                        decimal price = reader.GetDecimal(reader.GetOrdinal("Price"));
                                        if (stockQuantity >= item.Quantity)
                                        {
                                            totalAmount = totalAmount + (price * item.Quantity);
                                            orderItems.Add(new OrderItem
                                            {
                                                ProductId = item.ProductId,
                                                Quantity = item.Quantity,
                                                PriceAtOrder = price
                                            });
                                        }
                                        else
                                        {
                                            createOrderResponseDTO.Message = $"Insufficient Stock for Product : {item.ProductId}";
                                            createOrderResponseDTO.IsCreated = false;
                                            return createOrderResponseDTO;
                                        }
                                    }
                                    else
                                    {
                                        createOrderResponseDTO.Message = $"Product Not Found for Product : {item.ProductId}";
                                        createOrderResponseDTO.IsCreated = false;
                                        return createOrderResponseDTO;
                                    }
                                    reader.Close();
                                }
                            }
                        }

                        using (var orderCommand = new SqlCommand(orderQuery, connection, transaction))
                        {
                            orderCommand.Parameters.AddWithValue("@customerId", order.CustomerId);
                            orderCommand.Parameters.AddWithValue("@TotalAmount", totalAmount);
                            orderCommand.Parameters.AddWithValue("@Status", "Pending");
                            orderCommand.Parameters.AddWithValue("@OrderDate", DateTime.Now);
                            var orderId = (int)await orderCommand.ExecuteScalarAsync();

                            foreach (var item in orderItems)
                            {
                                using (var itemCommand = new SqlCommand(itemQuery, connection, transaction))
                                {
                                    itemCommand.Parameters.AddWithValue("@orderId", orderId);
                                    itemCommand.Parameters.AddWithValue("@ProductId", item.ProductId);
                                    itemCommand.Parameters.AddWithValue("@Quantity", item.Quantity);
                                    itemCommand.Parameters.AddWithValue("@PriceAtOrder", item.PriceAtOrder);
                                    await itemCommand.ExecuteNonQueryAsync();
                                }
                            }
                            transaction.Commit();
                            createOrderResponseDTO.Status = "Pending";
                            createOrderResponseDTO.IsCreated = true;
                            createOrderResponseDTO.OrderId = orderId;
                            createOrderResponseDTO.Message = "Order Created Successfully";
                            return createOrderResponseDTO;
                        }
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }

        public async Task<ConfirmOrderResponseDTO> confirmOrderResponseAsync(int orderId)
        {
            var orderQuery = "select totalamount from orders where orderid =@orderId";
            var paymentQuery = "select amount,status from payments where orderid =@orderId";
            var updateOrderStatusQuery = "update orders set status = 'Confirmed' where orderid =@orderId";
            var getOrderItemsQuery = "select productId,Quantity from orderitems where orderid =@orderId";
            var updateProductQuery = "update products set quantity = Quantity - @Quantity where productId = @ProductId";

            ConfirmOrderResponseDTO confirmOrderResponseDTO = new ConfirmOrderResponseDTO()
            {
                OrderId = orderId
            };
            using (var connection = _factory.CreateConnection())
            {
                await connection.OpenAsync();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        decimal orderAmount = 0m;
                        decimal paymentAmount = 0m;
                        string paymentStatus = string.Empty;
                        using (var orderCommand = new SqlCommand(orderQuery, connection, transaction))
                        {
                            orderCommand.Parameters.AddWithValue("@orderId", orderId);
                            using (var reader = await orderCommand.ExecuteReaderAsync())
                            {
                                if (await reader.ReadAsync())
                                {
                                    orderAmount = reader.GetDecimal(reader.GetOrdinal("totalamount"));
                                }
                                reader.Close();
                            }
                        }
                        using (var paymentCommand = new SqlCommand(paymentQuery, connection, transaction))
                        {
                            paymentCommand.Parameters.AddWithValue("@orderId", orderId);
                            using (var reader = await paymentCommand.ExecuteReaderAsync())
                            {
                                if (await reader.ReadAsync())
                                {
                                    paymentAmount = reader.GetDecimal(reader.GetOrdinal("Amount"));
                                    paymentStatus = reader.GetString(reader.GetOrdinal("status"));
                                }
                                reader.Close();

                            }
                        }
                        if (paymentStatus == "Completed" && paymentAmount == orderAmount)
                        {
                            using (var itemCommand = new SqlCommand(getOrderItemsQuery, connection, transaction))
                            {
                                itemCommand.Parameters.AddWithValue("@orderId", orderId);
                                using (var reader = await itemCommand.ExecuteReaderAsync())
                                {
                                    while (reader.Read())
                                    {
                                        int productId = reader.GetInt32(reader.GetOrdinal("ProductId"));
                                        int Quantity = reader.GetInt32(reader.GetOrdinal("Quantity"));
                                        using (var updateProductCommand = new SqlCommand(updateProductQuery, connection, transaction))
                                        {
                                            updateProductCommand.Parameters.AddWithValue("@ProductId", productId);
                                            updateProductCommand.Parameters.AddWithValue("@Quantity", Quantity);
                                            await updateProductCommand.ExecuteNonQueryAsync();
                                        }
                                    }

                                    reader.Close();
                                }
                            }

                            using (var statusCommand = new SqlCommand(updateOrderStatusQuery, connection, transaction))
                            {
                                statusCommand.Parameters.AddWithValue("@orderId", orderId);
                                await statusCommand.ExecuteNonQueryAsync();
                            }
                            transaction.Commit();
                            confirmOrderResponseDTO.IsConfirmed = true;
                            confirmOrderResponseDTO.Message = "Order Confirmed Successfully";
                            return confirmOrderResponseDTO;
                        }
                        else
                        {
                            transaction.Rollback();
                            confirmOrderResponseDTO.IsConfirmed = false;
                            confirmOrderResponseDTO.Message = "can not confirm Order";
                            return confirmOrderResponseDTO;
                        }
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw new Exception(ex.Message);
                    }
                }
            }
        }

        public bool IsValidStatus(string oldstatus, string newstatus)
        {
            switch (oldstatus)
            {
                case "pending": return newstatus == "Processing" || newstatus == "Cancelled";
                case "Confirmed": return newstatus == "Processing" ;
                case "Processing": return newstatus == "Delivered" ;
                case "Delivered": return false ;
                case "Cancelled": return false ;
                    default: return false;
            }
        }

        public async Task<OrderStatusResponseDTO> UpdateOrderStatusAsync(int OrderId, string status)
        {
            OrderStatusResponseDTO orderStatusResponseDTO = new OrderStatusResponseDTO()
            {
                OrderId = OrderId
            };
            using (var connection = _factory.CreateConnection())
            {
                await connection.OpenAsync();
                try 
                {
                    var StatusQuery = "select status from orders where orderId= @OrderId";
                    string CurrentStatus;
                    using (var statusCommand = new SqlCommand(StatusQuery, connection))
                    {
                        statusCommand.Parameters.AddWithValue("@OrderId", OrderId);
                        var result = await statusCommand.ExecuteScalarAsync();
                        if (result == null)
                        {
                            orderStatusResponseDTO.Message = "Order not found";
                            orderStatusResponseDTO.IsUpdated = false;
                            return orderStatusResponseDTO;
                        }
                        CurrentStatus =result.ToString();
                    }

                    if (IsValidStatus(CurrentStatus, status))
                    {
                        orderStatusResponseDTO.Message = $"Invalid Transition from {CurrentStatus} to {status}";
                        orderStatusResponseDTO.IsUpdated = false;
                        return orderStatusResponseDTO;
                    }
                    var updateStatusQuery = "update orders set status = @status where orderid = @OrderId";
                    using (var updateStatusCommand = new SqlCommand(updateStatusQuery, connection))
                    {
                        updateStatusCommand.Parameters.AddWithValue("@status",status);
                        updateStatusCommand.Parameters.AddWithValue("@OrderId",OrderId);
                        int rowsAffected = await updateStatusCommand.ExecuteNonQueryAsync();
                        if (rowsAffected > 0)
                        {
                            orderStatusResponseDTO.Message = $"Order status updated to {status}";
                            orderStatusResponseDTO.IsUpdated = true;
                            orderStatusResponseDTO.Status = status;
                            return orderStatusResponseDTO;
                        }
                        else
                        {
                            orderStatusResponseDTO.Message = $"Order status not updated";
                            orderStatusResponseDTO.IsUpdated = false;
                            return orderStatusResponseDTO;
                        }
                        
                    }
                    
                }
                catch (Exception ex) 
                {
                    throw;
                }

            }

            
        }
       
        public async Task<Order> getOrderDetailsAsync(int orderId)
        {  Order order = new Order();
            var orderQuery = "select orderId,CustomerId,Totalamount,status,OrderDate from orders where orderid =@orderId";
            using (var connection = _factory.CreateConnection())
            {
                await connection.OpenAsync();
                using (var command = new SqlCommand(orderQuery, connection))
                {
                    command.Parameters.AddWithValue("@orderId",orderId);
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                            order = new Order
                            {
                                OrderId = reader.GetInt32(reader.GetOrdinal("OrderId")),
                                CustomerId = reader.GetInt32(reader.GetOrdinal("CustomerId")),
                                TotalAmount = reader.GetDecimal(reader.GetOrdinal("TotalAmount")),
                                Status = reader.GetString(reader.GetOrdinal("Status")),
                                OrderDate = reader.GetDateTime(reader.GetOrdinal("OrderDate"))
                            };
                    }
                }
            }
            return order;
        }
    }
}
