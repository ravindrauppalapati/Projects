﻿using Azure;
using ECommWEBAPI.DTOs;
using ECommWEBAPI.Models;
using ECommWEBAPI.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Runtime.InteropServices.Marshalling;

namespace ECommWEBAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    
    public class OrderController : ControllerBase
    {
        private readonly OrderRepository _orderRepo;
        public OrderController(OrderRepository order)
        {
            _orderRepo = order;
        }

        [HttpGet]
        public async Task<ActionResult<APIResponse<List<Order>>>> GetAllOrders(string status = "Pending")
        {
            try
            {
                var orders = await _orderRepo.getAllOrdersAsync(status);
                return Ok(new APIResponse<List<Order>>(orders, "Retrieved All order Details Succesfully"));

            }
            catch (Exception EX)
            {
                return StatusCode(500, new APIResponse<List<Order>>(HttpStatusCode.InternalServerError, EX.Message));
            }
        }


        [HttpPost]
        public async Task<APIResponse<CreateOrderResponseDTO>> CreateOrder([FromBody] OrderDTO order)
        {
            if (!ModelState.IsValid)
            {
                return new APIResponse<CreateOrderResponseDTO>(HttpStatusCode.BadRequest, "Invalid Data", ModelState);
            }
            try { 
              var response = await _orderRepo.CreateOrderAsync(order);
                return new APIResponse<CreateOrderResponseDTO>(response, response.Message);
            }
            catch (Exception EX)
            {
                return new APIResponse<CreateOrderResponseDTO>(HttpStatusCode.InternalServerError, EX.Message);
            }
        }

        [HttpGet("{id}")]
        public async Task<APIResponse<Order>> GetOrderById(int id)
        {
            try
            {
                var order =await _orderRepo.getOrderDetailsAsync(id);
                if (order == null)
                    return new APIResponse<Order>(HttpStatusCode.NotFound, "Order Not Found");
               
                return new APIResponse<Order>(order, "Order retrived Successfully");

            }
            catch (Exception ex)
            {
                return new APIResponse<Order>(HttpStatusCode.InternalServerError,  ex.Message);
            }
           
        }

        [HttpPut("{id}/status")]
        public async Task<APIResponse<OrderStatusResponseDTO>> UpdateOrderStatus(int id, [FromBody] OrderStatusDTO orderStatus)
        {
            if (!ModelState.IsValid)
            {
                return new APIResponse<OrderStatusResponseDTO>(HttpStatusCode.BadRequest, "Invalid Data", ModelState);
            }
            if (id != orderStatus.OrderId)
            {
                return new APIResponse<OrderStatusResponseDTO>(HttpStatusCode.BadRequest, "Mismatched Id");
            }
            try
            {
                var response = await _orderRepo.UpdateOrderStatusAsync(id, orderStatus.Status);
                return new APIResponse<OrderStatusResponseDTO>(response, response.Message);

            }
            catch (Exception ex)
            {
                return new APIResponse<OrderStatusResponseDTO>(HttpStatusCode.InternalServerError,ex.Message);
            }
        }

        [HttpPut("{id}/confirm")]
        public async Task<APIResponse<ConfirmOrderResponseDTO>> ConfirmOrder(int id)
        {
            try
            {
                var response = await _orderRepo.confirmOrderResponseAsync(id);
                return new APIResponse<ConfirmOrderResponseDTO>(response, response.Message);
            }
            catch (Exception ex)
            {
                return new APIResponse<ConfirmOrderResponseDTO>(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}
