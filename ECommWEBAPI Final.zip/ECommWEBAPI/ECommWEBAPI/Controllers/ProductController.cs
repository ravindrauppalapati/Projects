﻿using ECommWEBAPI.DTOs;
using ECommWEBAPI.Models;
using ECommWEBAPI.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using System.Net;

namespace ECommWEBAPI.Controllers
{
    [ApiController] 
    [Route("api/[controller]")]
   
    public class ProductController : ControllerBase
    {
        private readonly ProductRepository _ProductRepo;
        public ProductController(ProductRepository productRepository)
        {
            _ProductRepo = productRepository;
        }
        [HttpGet]
        public async Task<APIResponse<List<Product>>> getAllProducts()
        {
            try
            {
                var products = await _ProductRepo.getAllProductsAsync();
                return new APIResponse<List<Product>>(products, "Retrived All Product Succesfully");

            }
            catch (Exception ex)
            {

                return new APIResponse<List<Product>>(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpGet("{id}")]
        public async Task<APIResponse<Product>> getProductById(int id)
        {
            try
            {
                var product = await _ProductRepo.getProductById(id);
                if (product == null)
                {
                    return new APIResponse<Product>(HttpStatusCode.NotFound, "product not found");
                }
                return new APIResponse<Product>(product, "Product retrieved Successfully");
            }
            catch (Exception ex)
            {
                return new APIResponse<Product>(HttpStatusCode.InternalServerError, ex.Message);
            }

        }

        [HttpPost]
        public async Task<APIResponse<ProductResponseDTO>> CreateProduct([FromBody] ProductDTO product)
        {
            if (!ModelState.IsValid)
            {
                return new APIResponse<ProductResponseDTO>(HttpStatusCode.BadRequest, "Invalid Data", ModelState);
            }
            try
            {
                var productId = await _ProductRepo.InsertProductAsync(product);
                var responseDto = new ProductResponseDTO { ProductId = productId };
                return new APIResponse<ProductResponseDTO>(responseDto, "Product Created Successfully");

            }
            catch (Exception ex)
            {
                return new APIResponse<ProductResponseDTO>(HttpStatusCode.InternalServerError, ex.Message);

            }
        }

        [HttpPut("{id}")]
        public async Task<APIResponse<bool>> UpdateProduct(int id, [FromBody] ProductDTO product)
        {
            if (!ModelState.IsValid)
            {
                return new APIResponse<bool>(HttpStatusCode.BadRequest, "Invalid Data", ModelState);
            }
            if (id != product.ProductId)
            {
                return new APIResponse<bool>(HttpStatusCode.BadRequest, "Mismatched Product Id");
            }
            try {
                await _ProductRepo.UpdateProductAsync(product);
                return new APIResponse<bool>(true, "Product Updated Successfully");
            }
            catch (Exception ex)
            {
                return new APIResponse<bool>(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public async Task<APIResponse<bool>> DeleteProduct(int id)
        {
            try
            {
                var product = await _ProductRepo.getProductById(id);
                if (product == null)
                {
                    return new APIResponse<bool>(HttpStatusCode.NotFound, "Product not found");
                }
                await _ProductRepo.DeleteProductAsync(id);
                return new APIResponse<bool>(true, "Product Deleted Successfully");
            }
            catch (Exception ex)
            {
                return new APIResponse<bool>(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

    }
}
