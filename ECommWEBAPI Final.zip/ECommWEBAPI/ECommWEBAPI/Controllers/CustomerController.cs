﻿using ECommWEBAPI.DTOs;
using ECommWEBAPI.Models;
using ECommWEBAPI.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace ECommWEBAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]

    public class CustomerController : ControllerBase
    {
        private readonly CustomerRepository _customerRepo;
        public CustomerController(CustomerRepository customerRepository)
        {
            _customerRepo = customerRepository;
        }

        [HttpGet]
        public async Task<APIResponse<List<Customer>>> GetAllCustomers()
        {
            try
            {
                var customers = await _customerRepo.getAllCustomersAsync();

                return new APIResponse<List<Customer>>(customers, "Retrieved All Customers Successfully");
            }
            catch (Exception ex)
            {
                return new APIResponse<List<Customer>>(HttpStatusCode.InternalServerError, "Internal Server Error " + ex.Message);
            }
        }
        [HttpGet("{id}")]
        public async Task<APIResponse<Customer>> getCustomerById(int id)
        {
            try
            {
                var customer = await _customerRepo.getCustomerById(id);
                if (customer == null)
                {
                    return new APIResponse<Customer>(HttpStatusCode.NotFound, "Customer Not Found");
                }
                return new APIResponse<Customer>(customer, "Customer retrieved Successfully");
            }

            catch (Exception ex)
            {
                return new APIResponse<Customer>(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpPost]
        public async Task<APIResponse<CustomerResponseDTO>> CreateCustomer([FromBody] CustomerDTO customer)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var customerId = await _customerRepo.InsertCustomerAsync(customer);
                    var responseDto = new CustomerResponseDTO { CustomerId = customerId };
                    return new APIResponse<CustomerResponseDTO>(responseDto, "Customer Created Successfully");
                }
                else
                {
                    return new APIResponse<CustomerResponseDTO>(HttpStatusCode.BadRequest, "Invalid Data", ModelState);
                }
            }
            catch (Exception ex)
            {
                return new APIResponse<CustomerResponseDTO>(HttpStatusCode.InternalServerError, ex.Message);

            }

        }

        [HttpPut("{id}")]
        public async Task<APIResponse<bool>> updateCustomer(int id, [FromBody] CustomerDTO customer)
        {
            if (!ModelState.IsValid)
            {
                return new APIResponse<bool>(HttpStatusCode.BadRequest, "Invalid Data", ModelState);
            }
            if (id != customer.CustomerId)
            {
                return new APIResponse<bool>(HttpStatusCode.BadRequest, "Mismatched Customer Id");
            }

            try
            {
                await _customerRepo.UpdateCustomerAsync(customer);
                return new APIResponse<bool>(true, "Customer Updated Successfully");
            }
            catch (Exception ex)
            {
                return new APIResponse<bool>(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public async Task<APIResponse<bool>> DeleteCustomer(int id)
        {
            try
            {
                var customer = _customerRepo.getCustomerById(id);
                if (customer == null)
                    return new APIResponse<bool>(HttpStatusCode.NotFound, "Customer Not Found");
                await _customerRepo.DeleteCustomerAsync(id);
                return new APIResponse<bool>(true, "Customer Deleted Successfully");
            }
            catch (Exception ex)
            {
                return new APIResponse<bool>(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}
