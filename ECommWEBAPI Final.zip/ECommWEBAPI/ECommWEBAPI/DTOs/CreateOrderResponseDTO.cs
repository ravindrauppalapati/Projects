﻿namespace ECommWEBAPI.DTOs
{
    public class CreateOrderResponseDTO
    {
        public int OrderId { get; set; }
        public string Status { get; set; }
        public bool IsCreated { get; set; }
        public string Message { get; set; }
    }
}
