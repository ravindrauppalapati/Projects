﻿using EmployeePortalApp.Data;
using EmployeePortalApp.Models;
using System.Collections.Specialized;

namespace EmployeePortalApp.Service
{
   
    public class EmployeeService
    {
        private readonly AppDBContext _context;
        public EmployeeService(AppDBContext context)
        {
            _context = context;
        }
        public async Task<(List<Employee> emp, int totalCount)> getEmployees(string searchItem, string selectedDepartment,
            string selectedType, int pageNumber, int PageSize)
        {
            var employees = _context.Employees.AsQueryable();
            if (!string.IsNullOrEmpty(searchItem))
            {
                employees = employees.Where(x => x.FullName.Contains(searchItem, StringComparison.OrdinalIgnoreCase));
            }
            if (!string.IsNullOrEmpty(selectedDepartment))
            {
                if (Enum.TryParse(selectedDepartment, out Department department))
                {
                    employees = employees.Where(x => x.Department == department);
                }
            }

            if (!string.IsNullOrEmpty(selectedType))
            {
                if (Enum.TryParse(selectedType, out EmployeeType type))
                {
                    employees = employees.Where(x => x.Type == type);
                }
            }

            int count = employees.Count();

            employees = employees.Skip((pageNumber - 1) * PageSize).Take(PageSize);

            return await Task.FromResult((employees.ToList(), count));
        }

        public Employee? getEmployeeById(int Id)
        {
            return _context.Employees.FirstOrDefault(x => x.Id == Id);
        }

        public void CreateEmployee(Employee employee)
        { 
            _context.Employees.Add(employee);
            _context.SaveChanges();
        }
        public void updateEmployee(Employee employee)
        {
            var emp = getEmployeeById(employee.Id);

            if (emp != null)
            {
                emp.FullName =employee.FullName;
                emp.Email =employee.Email;
                emp.Position =employee.Position;
                emp.Department =employee.Department;
                emp.HireDate =employee.HireDate;
                emp.DateOfBirth =employee.DateOfBirth;
                emp.Type =employee.Type;
                emp.Gender =employee.Gender;
                emp.Salary =employee.Salary;
            }
            _context.SaveChanges();
        }

        public void deleteEmployee(int Id)
        {
            var emp = getEmployeeById(Id);
            if(emp != null)
            {
                _context.Employees.Remove(emp);
                _context.SaveChanges();
            }
        }
    }
}
