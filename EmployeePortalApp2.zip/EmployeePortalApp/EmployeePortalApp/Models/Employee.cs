﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace EmployeePortalApp.Models
{
    public class Employee
    {
        public int Id { get; set; }
        [Required]
        [StringLength(100)]
        [Display(Name ="Full Name")]
        public string FullName { get; set; }
        [Required] 
        [Display(Name = "Email Address")]
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        [StringLength(50)] 
        public string Position { get; set; }
        [Required]
        public Department? Department { get; set; }
        [Required]
        [DataType(DataType.Date)]
        [Display(Name ="Hire Date")]

        public DateTime? HireDate { get; set; }
        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Date of Birth")]
        public DateTime? DateOfBirth { get; set; }
        [Required]
        [StringLength (10)]
        public string Gender { get; set; }
        [Required]
        [Range(0,double.MaxValue)]
        [DataType(DataType.Currency)]
        public decimal? Salary { get; set; }
        [Required]
        [Display(Name ="Employee Type")]
        public EmployeeType? Type { get; set; }
    }
}
