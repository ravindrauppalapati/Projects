﻿using EmployeePortalApp.Models;
using Microsoft.EntityFrameworkCore;
namespace EmployeePortalApp.Data
{
    public class AppDBContext : DbContext
    {
        public AppDBContext(DbContextOptions<AppDBContext> opts):base(opts) { }
        
        public DbSet<Employee> Employees { get; set; }
    }
}
