﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Register_LogIn_LogOut_Identity.Models;

namespace Register_LogIn_LogOut_Identity.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<Register_LogIn_LogOut_Identity.Models.RegisterViewModel> RegisterViewModel { get; set; } = default!;
        public DbSet<Register_LogIn_LogOut_Identity.Models.LoginViewModel> LoginViewModel { get; set; } = default!;
    }
}
