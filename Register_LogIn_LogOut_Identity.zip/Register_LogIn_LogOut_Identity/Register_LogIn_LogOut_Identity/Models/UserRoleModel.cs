﻿using System.ComponentModel.DataAnnotations;

namespace Register_LogIn_LogOut_Identity.Models
{
    public class UserRoleModel
    {
        [Key]
        public string UserId { get; set; }
        [Required]
        public string UserName { get; set; }
        public bool IsSelected { get; set; }
    }
}
