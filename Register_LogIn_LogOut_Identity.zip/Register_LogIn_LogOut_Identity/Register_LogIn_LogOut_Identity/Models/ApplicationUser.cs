﻿using Microsoft.AspNetCore.Identity;

namespace Register_LogIn_LogOut_Identity.Models
{
    public class ApplicationUser : IdentityUser
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Country { get; set; }
        public string State { get; set; }
    }
}
